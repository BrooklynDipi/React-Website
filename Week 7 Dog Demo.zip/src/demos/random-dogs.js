import { useState, useEffect } from "react";
import LoadingSpinner from "../common/loading-spinner";
import ErrorMessage from "../common/error-message";
import "../index.css"

function RandomDogs() {

  const [dogFetch, setDogFetch] = useState({
      isLoading: true, 
      ErrorMessage: "",
      data: null,

  });

  const {isLoading, errorMessage, data} = dogFetch;

  useEffect(() => {
    async function getDog(){
      try {
        const url = "https://dog.ceo/api/breeds/image/random";
        const response = await fetch(url);


      if (!response.ok){
        throw new Error(`Something went wrong!`)
      }

      const json = await response.json();
      const { message, status } = json;

      if (status != "success"){
        throw new Error("Bad API Request - no results!");
      } 

      setDogFetch({
        isLoading: false,
        errorMessage: "",
        data: message,
      });
    } catch (err){      
        setDogFetch({
        isLoading: false,
        errorMessage: "Something went wrong loading the dog, please try again!",
        data: null,

    });
    console.error(err);
      }
    }
    getDog();
  }, []);

  let contents;
  if (isLoading) contents = <LoadingSpinner />;
  else if (errorMessage !== "") contents = <ErrorMessage>{errorMessage}</ErrorMessage>
  else contents = [
    <img class="dogimg" alt="dog" src={data}></img>,
    <img class="dogimg" alt="dog" src={data}></img>,
    <img class="dogimg" alt="dog" src={data}></img>,
    <img class="dogimg" alt="dog" src={data}></img>,
    <img class="dogimg" alt="dog" src={data}></img>];

  return (
    <main>{contents}</main>
  );
}

export default RandomDogs;