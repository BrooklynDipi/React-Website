import Game from "./game";
import { useState, useEffect } from "react";
import LoadingSpinner from "../common/loading-spinner";
import ErrorMessage from "../common/error-message";

function QuizPage() {

  const [quizFetch, setQuizFetch] = useState({
      isLoading: true, 
      ErrorMessage: "",
      data: null,

  });

  const {isLoading, errorMessage, data} = quizFetch;

  useEffect(() => {
    async function getQuiz(){
      try {
        const url = "https://opentdb.com/api.php?amount=5&type=multiple";
        const response = await fetch(url);


      if (!response.ok){
        throw new Error(`Something went wrong!`)
      }

      const json = await response.json();
      const { response_code, results } = json;

      if (response_code === 1){
        throw new Error("Bad API Request - no results!");
      } else if (response_code === 2) {
        throw new Error("Bad AP Request - invalid!");
      }

      setQuizFetch({
        isLoading: false,
        errorMessage: "",
        data: results,
      });
    } catch (err){      
      setQuizFetch({
        isLoading: false,
        errorMessage: "Something went wrong loading the Quiz, please try again!",
        data: null,

    });
    console.error(err);
      }
    }
    getQuiz();
  }, []);

  let contents;
  if (isLoading) contents = <LoadingSpinner />;
  else if (errorMessage !== "") contents = <ErrorMessage>{errorMessage}</ErrorMessage>
  else contents = <Game triviaData={data}/>;

  return (
    <main>{contents}</main>
  );
}

export default QuizPage;
