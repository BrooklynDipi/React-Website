function VizPage() {
  return (
    <main>
      <p>See HW challenge solution for what we did on this page 😉</p>
    </main>
  );
}

export default VizPage;
